#include <stdio.h>
#include "base.h"
#include <stdlib.h>



int main (int argc, char const *argv[])
{
	rbtree* mosaico;
	int mosaico_is_active= 0;
	int flag = 1;
	int param[2];
	char* cmd = (char*) malloc(sizeof(char));
	printf("Digitare il carattere dell'operazione da svolgere secondo il seguente menu:\n");
	printf("n  inizializza un nuovo mosaico \n");
	printf("i  inserisce a caso una tessera\n");
	printf("I (x,y)  inserisce una tessera alle coordinate x,y\n");
	printf("c n  costruisce un mosaico di n tessere\n");	
	printf("p restituisce il perimetro del mosaico\n");
	printf("o resitutisce l'ordine del mosaico\n");
	printf("s (n, k) stampa il valore medio dei k valori di a e di b\n");
	
	while(flag){
		printf(">");
	   scanf("%s", cmd);
			   switch (cmd[0]){
			case 'n':
				printf("Creato Nuovo mosaico \n");
				mosaico = nuovo();
				mosaico_is_active = 1;
				
				break;
			case 'o':
				if (!mosaico_is_active){
					printf("devi creare prima un mosaico seleziona n");
					break;
				}
					
				printf("%d",ordine(mosaico));
				break;
			case 'p':
			if (!mosaico_is_active){
				printf("devi creare prima un mosaico seleziona n");
				break;
			}
				printf("%d",perimetro(mosaico));
				break;
				
			case 'c':
			
				
				if (!mosaico_is_active){
					printf("devi creare prima un mosaico seleziona n");
					break;
				}
				scanf("%d", param);
		
				costruisci(mosaico,param);
			break;
			
			case 's':
			
				
				if (!mosaico_is_active){
					printf("devi creare prima un mosaico seleziona n");
					break;
				}
				scanf("%d", param);
				scanf("%d", param+1);
				statistica(mosaico, param[0],param[1]);
			break;
			case 'i':
					if (!mosaico_is_active){
						printf("devi creare prima un mosaico seleziona n");
						break;
					}
                        scanf("%d", param);
						scanf("%d", param+1);
						
                        if (rbinsert(mosaico, param[0], param[1]) == -1)
							printf("errore");
				
					break;
			case 'I':
				inserisci_a_caso(mosaico);
				break;
			case 'v':
			    visualizza_avanzata(mosaico);
				break;
				case 'q':
				 flag = 0;
	                break;
			}
			
			
			printf("\n");
	}
	 return 0;
}